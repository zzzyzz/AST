# Brief Introduction of JDT_AST_DOT Project

This project is used for generating an AST for a given Java class.

Moreover, we tranfer the generated AST in .dot format.
