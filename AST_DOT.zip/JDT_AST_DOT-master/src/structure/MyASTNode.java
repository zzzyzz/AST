package structure;

import org.eclipse.jdt.core.dom.ASTNode;

public class MyASTNode {

	public ASTNode astNode = null;
	public int lineNum = -1;
}
